
const canvas = document.getElementById("confetti-canvas");
const ctx = canvas.getContext("2d");

canvas.width = window.innerWidth;
canvas.height = window.innerHeight;

const pieces = Array.from({ length: 100 }, () => ({
  x: Math.random() * canvas.width,
  y: Math.random() * canvas.height - canvas.height,
  r: Math.random() * 5 + 2,
  d: Math.random() * 0.5 + 0.5
}));

function draw() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  ctx.fillStyle = "#f39c12";
  pieces.forEach(p => {
    ctx.beginPath();
    ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
    ctx.fill();
  });
  update();
}

function update() {
  pieces.forEach(p => {
    p.y += p.d * 4;
    if (p.y > canvas.height) {
      p.y = 0 - p.r;
      p.x = Math.random() * canvas.width;
    }
  });
}

setInterval(draw, 30);
